var t=`<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="-2 -3 12 6">
<rect x="-2" y="-3" width="4" height="6" fill="#ce1126"/>
<rect x="2" y="-3" width="8" height="3" fill="#fcd116"/>
<rect x="2" width="8" height="3" fill="#009e49"/>
<g id="c">
<path id="t" d="M 0,-1 v 1 h .5" transform="rotate(18 0,-1)" fill="#000"/>
<use xlink:href="#t" transform="scale(-1,1)"/>
</g>
<use xlink:href="#c" transform="rotate(72)"/>
<use xlink:href="#c" transform="rotate(144)"/>
<use xlink:href="#c" transform="rotate(216)"/>
<use xlink:href="#c" transform="rotate(288)"/>
</svg>
`;export{t as default};
