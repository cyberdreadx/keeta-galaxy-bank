var e=`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 700 600">
<rect width="700" height="600" fill="#0DB02B"/>
<rect width="700" height="400" fill="#FFF"/>
<rect width="700" height="200" fill="#e05206"/>
<circle cx="350" cy="300" r="85" fill="#e05206"/>
</svg>
`;export{e as default};
