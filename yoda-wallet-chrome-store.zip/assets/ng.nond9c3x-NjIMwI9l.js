var t=`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 6 3">
<rect width="6" height="3" fill="#008751"/>
<rect x="2" width="2" height="3" fill="#FFF"/>
</svg>
`;export{t as default};
